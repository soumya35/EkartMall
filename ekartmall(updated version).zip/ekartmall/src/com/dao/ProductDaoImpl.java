package com.dao;
import com.database.ConnectionFactory;
import com.model.Category;
import com.model.Product;
import com.dao.ProductDao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ProductDaoImpl implements ProductDao {
	
	Connection con;
	

	@Override
	public boolean save(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 System.out.println("Inserting records into the table...");
	            PreparedStatement stmt = con.prepareStatement("insert into Product(CategoryId,ProductName,Quantity,Price) values(?,?,?,?)");
	            stmt.setInt(1,p.getCategoryid());
	            stmt.setString(2, p.getProductname());
	            stmt.setInt(3, p.getQuantity());
	            stmt.setDouble(4, p.getPrice());
	            
	            int i = stmt.executeUpdate();
	            System.out.println(i + " records inserted");	                       
	            stmt.close();
	            con.close();
	            return true;
	            
		} catch (SQLException e) {
            System.out.println(e);
        }
		return false;
	}
	
	
	
	

	@Override
	public boolean update(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			
			 System.out.println("Update process starting...");
			 PreparedStatement stmt = con.prepareStatement("update Product set CategoryId=?, ProductName=?,Quantity=?,Price=? where ProductId=?");
		
			 stmt.setInt(1, p.getCategoryid());
			 stmt.setString(2,p.getProductname());
			 stmt.setInt(3, p.getQuantity());
			 stmt.setDouble(4, p.getPrice());
			 stmt.setInt(5, p.getProductid());
			 
			 boolean rowUpdated = stmt.executeUpdate() > 0;
			 con.close();
			 return rowUpdated;
		} catch (SQLException e) {
            System.out.println(e);
        }
		return false;
	}

	
	
	
	@Override
	public boolean delete(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 
			 System.out.println("Delete process starting...");
			 PreparedStatement stmt = con.prepareStatement("DELETE FROM Product where ProductId = ?");
			 stmt.setInt(1,p.getProductid());  
			 
			 boolean rowDeleted = stmt.executeUpdate() > 0;
			 con.close();
		return rowDeleted;
		} catch (SQLException e) {
           System.out.println(e);
       }
		return false;
	}

	@Override
	public boolean view(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 
			 System.out.println("Viewing operation starting...");
			 PreparedStatement stmt = con.prepareStatement("select * from Product where ProductId=?");
			 stmt.setInt(1,p.getProductid()); 
			 ResultSet rs=stmt.executeQuery();
			 if(rs.next()){ 
			 
			 stmt.setInt(1,p.getProductid());
			 stmt.setInt(2, p.getCategoryid());
			 stmt.setString(3, p.getProductname());
			 stmt.setInt(4, p.getQuantity());
			 stmt.setDouble(5, p.getPrice());
			 }
			 con.close(); 
		} catch (SQLException e) {
           System.out.println(e);
       }
		return false;
		
	}

	
	
	
	@Override
	public List<Product> listAllProducts() {
		 List<Product> listproduct = new ArrayList<>();
		 try {
			 String sql = "SELECT * FROM Product";
	         
		        con=ConnectionFactory.getDBConnection();
		         
		        Statement statement = con.createStatement();
		        ResultSet resultSet = statement.executeQuery(sql);
		        
		        
		        while (resultSet.next()) {
		        	 int id = resultSet.getInt("productid");
		        	 int cid = resultSet.getInt("CategoryId");
		        	 String name = resultSet.getString("productname");
		        	 int quantity = resultSet.getInt("Quantity");
		        	 Double price=resultSet.getDouble("price");
		        	 
		        	 Product product = new Product(id,cid,name,quantity,price);
			            listproduct.add(product);
			        }
		        
		        for(Product p:listproduct)
		        {
		        	System.out.println("pid:"+p.getProductid());
		        	System.out.println("name:"+p.getProductname());
		        }
		        resultSet.close();
		        statement.close();
		         
		        
			}
			catch(Exception e)
			{
				System.out.println(e.toString());
			}
		        
		 
		 
		 
		 
		return listproduct;
	}





	@Override
	public int getLastProductid() {
		try {
			con = ConnectionFactory.getDBConnection();
			
			 System.out.println("fetching product id from Database");
			 
			
			 
			 Statement statement = con.createStatement();
			 ResultSet resultSet = statement.executeQuery("select top 1* from product order by productid desc");
			resultSet.next();
			int pid=resultSet.getInt("productid");
			 System.out.println(pid + " records fetched");	                       
			 statement.close();            
	            con.close();
	            return pid;
		} 
		
	 catch (SQLException e) {
        System.out.println(e);
    }
		return 0;
	}

	
}
