package com.dao;
import com.database.ConnectionFactory;
import com.model.User;

//import javax.servlet.ServletContext;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
*
* @author Soumya & Titas
*/

public class UserDaoImpl implements UserDao {

    Connection con;

    @Override
    public boolean save(User user) {

        try {

          
            con = ConnectionFactory.getDBConnection();

            System.out.println("Inserting records into the table...");
            PreparedStatement stmt = con.prepareStatement("insert into User2 values(?,?,?,?,?,?,?)");
            user.setRole("user");
            stmt.setString(1, user.getFirstName());
            stmt.setString(2, user.getLastName());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getPassword());
            stmt.setString(5, user.getAddress());
            stmt.setString(6, user.getPhonenumber());
            stmt.setString(7, user.getRole());

            int i = stmt.executeUpdate();
            System.out.println(i + " records inserted");
            
            stmt.close();
            con.close();
            return true;

        } catch (SQLException e) {
            System.out.println(e);
        }
return false;
    }
    
    public List<User> getDetails() throws SQLException
    {
        con=ConnectionFactory.getDBConnection();
          Statement st=con.createStatement();
                  ResultSet      rs=st.executeQuery("Select * from user2");
			
                  User u=new User();
			List<User> listUser=new ArrayList<User>();
                        
                     while(rs.next())   
                     {
                         u.setFirstName(rs.getString("First Name"));
                        
                         listUser.add(u);
                     }
                     rs.close();
                     return listUser;
			
    }
    
      
        
  	
  	
  	
       
	@Override
	public User login(User user) throws SQLException {
		 
	
         String Email = user.getEmail().trim();    
         String password = user.getPassword().trim();   
	    
         String searchQuery =
               "select * from User2 where Email='"+ Email+ "' AND password='"+ password+ "'";
	    
      // "System.out.println" prints in the console; Normally used to trace the process
      System.out.println("Your user name is " + Email);          
      System.out.println("Your password is " + password);
      System.out.println("Query: "+searchQuery);
      
      try
      {
      
      con=ConnectionFactory.getDBConnection();
    
      Statement stmt=con.createStatement();
     
      ResultSet rs = stmt.executeQuery(searchQuery);	
    
      boolean more = rs.next();
     
      
      if (!more) 
      {
         System.out.println("Sorry, you are not a registered user! Please sign up first");
         user.setValid(false);
      } 
	        
      //if user exists set the isValid variable to true
      else if (more) 
      {
       
        
         user.setFirstName( rs.getString("FirstName"));
         user.setLastName(rs.getString("LastName"));
         user.setEmail(rs.getString("Email"));
         user.setEmail(rs.getString("Role"));
         user.setValid(true);
      }
      }
      catch (Exception ex){
    	  System.out.println("Log In failed: An Exception has occurred! " + ex);
      }
      
	       
	
	
     
     
    
      return user;
	}
	
	
	
	
	
	
	
}

