package com.dao;
import com.database.ConnectionFactory;
import com.model.Category;
import com.model.Product;
import com.dao.ProductDao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ProductDaoImpl implements ProductDao {
	
	Connection con;
	

	@Override
	public boolean save(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 System.out.println("Inserting records into the table...");
	            PreparedStatement stmt = con.prepareStatement("insert into Product(ProductName,Quantity,Price) values(?,?,?)");
	            stmt.setString(1, p.getProductname());
	            stmt.setInt(2, p.getQuantity());
	            stmt.setDouble(3, p.getPrice());
	            
	            int i = stmt.executeUpdate();
	            System.out.println(i + " records inserted");
	            
	            stmt.close();
	            con.close();
	            return true;
	            
		} catch (SQLException e) {
            System.out.println(e);
        }
		return false;
	}
	
	
	
	

	@Override
	public boolean update(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			
			 System.out.println("Update process starting...");
			 PreparedStatement stmt = con.prepareStatement("update Product set ProductName=?,Quantity=?,Price=? where ProductId=?");
		
			 stmt.setString(1,p.getProductname());
			 stmt.setInt(2, p.getQuantity());
			 stmt.setDouble(3, p.getPrice());
			 stmt.setInt(4, p.getProductid());
			 
			 boolean rowUpdated = stmt.executeUpdate() > 0;
			 con.close();
			 return rowUpdated;
		} catch (SQLException e) {
            System.out.println(e);
        }
		return false;
	}

	
	
	
	@Override
	public boolean delete(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 
			 System.out.println("Delete process starting...");
			 PreparedStatement stmt = con.prepareStatement("DELETE FROM Product where ProductId = ?");
			 stmt.setInt(1,p.getProductid());  
			 
			 boolean rowDeleted = stmt.executeUpdate() > 0;
			 con.close();
		return rowDeleted;
		} catch (SQLException e) {
           System.out.println(e);
       }
		return false;
	}

	@Override
	public boolean view(Product p) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 
			 System.out.println("Viewing operation starting...");
			 PreparedStatement stmt = con.prepareStatement("select * from Product where ProductId=?");
			 stmt.setInt(1,p.getProductid()); 
			 ResultSet rs=stmt.executeQuery();
			 if(rs.next()){ 
			 
			 stmt.setInt(1,p.getProductid());
			 stmt.setInt(2, p.getCategoryid());
			 stmt.setString(3, p.getProductname());
			 stmt.setInt(4, p.getQuantity());
			 stmt.setDouble(5, p.getPrice());
			 }
			 con.close(); 
		} catch (SQLException e) {
           System.out.println(e);
       }
		return false;
		
	}

	
	
	
	@Override
	public List<Product> listAllProducts() {
		 List<Product> listProduct = new ArrayList<>();
		 try {
			 String sql = "SELECT * FROM Product";
	         
		        con=ConnectionFactory.getDBConnection();
		         
		        Statement statement = con.createStatement();
		        ResultSet resultSet = statement.executeQuery(sql);
		        
		        
		        while (resultSet.next()) {
		        	 int id = resultSet.getInt("productid");
		        	 int cid = resultSet.getInt("categoryid");
		        	 String name = resultSet.getString("productName");
		        	 int quantity = resultSet.getInt("quantity");
		        	 Double price=resultSet.getDouble("price");
		        	 
		        	 Product product = new Product(id,cid,name,quantity,price);
			            listProduct.add(product);
			        }
		        resultSet.close();
		        statement.close();
		         
		        
			}
			catch(Exception e)
			{
				System.out.println(e.toString());
			}
		        
		 
		 
		 
		 
		return listProduct;
	}

}
