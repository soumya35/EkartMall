package com.dao;
import java.sql.SQLException;
import java.util.List;

import com.model.Cart;
import com.model.Cartitem;

public interface CartitemDao {

	public boolean AddItemtoCart(Cartitem cartitem);
	public boolean delete(Cartitem cartitem);
	public int itemCount(int cartid);
	 public List<Cartitem> listAllCartItem();
	
	
}
