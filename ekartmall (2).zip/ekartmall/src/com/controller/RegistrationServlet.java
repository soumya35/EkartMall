package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao;
import com.dao.UserDaoImpl;
import com.model.User;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public RegistrationServlet() {
       
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstname=request.getParameter("FirstName");
		String lastname=request.getParameter("LastName");
		String email=request.getParameter("email");
		String password=request.getParameter("Password");
		String address=request.getParameter("Address");
		
		
		
		
		
		User user=new User();
		user.setFirstName(firstname);
		user.setLastName(lastname);
		user.setPassword(password);
		user.setAddress(address);
	
		UserDao userDao=new UserDaoImpl();
		if(userDao.save(user))
		{
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
			rd.forward(request, response);
			
		}
		else
		{
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/signupform.jsp");
			rd.forward(request, response);
			
		}
}
}
