package com.model;

public class Product {
	
	int productid;
	int categoryid;
	String productName;
	int quantity;
	double price;
	
	
	public Product() {
    }
	
	public Product(int productid,int categoryid,int quantity) {
		this.productid=productid;
		this.categoryid=categoryid;
		this.quantity=quantity;
    }
	
	
	public Product(int productid,int categoryid,String productName,int quantity,double price) {
		this(productName,price);
        this.productid = productid;
        this.categoryid=categoryid;
        this.quantity=quantity;
        
    }
	
	
	
	
	public Product( String name,  Double Price) {
		this.productName=name;
		this.price=Price;
		
		
		
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	public String getProductname() {
		return productName;
	}
	public void setProductname(String productname) {
		this.productName = productname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

}
