package com.model;

public class Category {

	int categoryid;
	String categoryName;
	String categoryDescription;
	public Category(int id, String name, String description) {
		
		this.categoryid=id;
		this.categoryName=name;
		this.categoryDescription=description;
		
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCategoryDescription() {
		return categoryDescription;
	}
	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}
	
	
}
