package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CategoryDao;
import com.dao.CategoryDaoImpl;
import com.model.Category;

/**
 * Servlet implementation class ViewCategory
 */
@WebServlet("/ViewCategory")
public class CategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CategoryController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		 String action = request.getParameter("action");
		 System.out.println("hello:"+action);
	        try {
	            switch (action) {
	            case "new":
	                showNewForm(request, response);
	                break;
	            case "insert":
	               insertCategory(request, response);
	                break;
	            case "delete":
	            	System.out.println("inside delete form");
	                deleteCategory(request, response);
	                break;
	            case "edit":
	            	System.out.println("inside edit form");
	                showEditForm(request, response);
	                break;
	            case "update":
	                updateCategory(request, response);
	                break;
	            default:
	                listCategory(request, response);
	                break;
	            }
	        }
	        catch (SQLException ex) {
	            throw new ServletException(ex);
	        }
	}
	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("inside edit form");
		int id = Integer.parseInt(request.getParameter("id"));
		 CategoryDao categoryDao=new CategoryDaoImpl();
       
		 
		 Category editCategory=categoryDao.getCategory(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/category.jsp");
        request.setAttribute("category", editCategory);
        dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
	private void insertCategory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String categoryName = request.getParameter("CategoryName");
        String categoryDescription = request.getParameter("Description");
        
        Category c=new Category();
        c.setCategoryName(categoryName);
        c.setCategoryDescription(categoryDescription);
        
        CategoryDao categoryDao=new CategoryDaoImpl();
        if(categoryDao.save(c))
        {
        	
        	   response.sendRedirect("ViewCategory?action=");
        }
     
        
	}

	private void listCategory(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		CategoryDao categoryDao=new CategoryDaoImpl();
		List<Category> listCategory = categoryDao.listAllCategories();
		request.setAttribute("listCategory", listCategory);
		RequestDispatcher dispatcher = request.getRequestDispatcher("CategoryList.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		
       System.out.println("hi open category page");
		  RequestDispatcher rd=getServletContext().getRequestDispatcher("/category.jsp");
		  rd.forward(request, response);
    }
	
	
	
	private void updateCategory(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
	    
        int id = Integer.parseInt(request.getParameter("categoryid"));
   
        String categoryName = request.getParameter("CategoryName");
        String categoryDescription = request.getParameter("Description");
        
        
        Category c=new Category();
        c.setCategoryName(categoryName);
        c.setCategoryDescription(categoryDescription);
        c.setCategoryid(id);
 
        CategoryDao categoryDao=new CategoryDaoImpl();
        if(categoryDao.update(c))
        {
        	
        	   response.sendRedirect("ViewCategory?action=");
        }
     
    }
	
	
	
	private void deleteCategory(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
	    
        int id = Integer.parseInt(request.getParameter("id"));
   
       
        Category c=new Category();
       
        c.setCategoryid(id);
 
        CategoryDao categoryDao=new CategoryDaoImpl();
        if(categoryDao.delete(c))
        {
        	
        	   response.sendRedirect("ViewCategory?action=");
        }
	

}
}


