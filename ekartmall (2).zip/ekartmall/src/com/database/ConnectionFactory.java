package com.database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
*
* @author Soumya & Titas
*/

public class ConnectionFactory {
	 String driverClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static String  connectionUrl ="jdbc:sqlserver://172.23.132.13;database=Ekart2;user=sa;password=password@123";
   
    
 public ConnectionFactory() 
 {         }
 
   public static Connection getConnection() throws SQLException {
       Connection conn = null;
       conn=DriverManager.getConnection(connectionUrl);   
       return conn;
   }

}
