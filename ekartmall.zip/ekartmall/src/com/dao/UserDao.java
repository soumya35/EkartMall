package com.dao;
import java.sql.SQLException;

import com.model.User;

/**
*
* @author Soumya & Titas
*/
public interface UserDao {
    
    public boolean save(User user);
   
    
    public  User login(User user) throws SQLException;

}