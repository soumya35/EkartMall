package com.dao;
import java.sql.SQLException;
import com.model.Cart;
import com.model.Product;

/**
*
* @author Soumya & Titas
*/


public interface CartDao {

	public boolean save(Cart cart);
	public boolean update(Cart cart);
	public boolean delete(Cart cart);
	public Cart getCart(int cid);
	
}
