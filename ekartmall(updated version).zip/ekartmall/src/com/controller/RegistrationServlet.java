package com.controller;

import java.io.IOException;
//import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CartDao;
import com.dao.CartDaoImpl;
import com.dao.UserDao;
import com.dao.UserDaoImpl;
import com.model.Cart;
import com.model.User;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public RegistrationServlet() {
       
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstname=request.getParameter("FirstName");
		String lastname=request.getParameter("LastName");
		String email=request.getParameter("email");
		String password=request.getParameter("psw");
		String address=request.getParameter("address");
		String phonenumber=request.getParameter("phonenumber");
		String role=request.getParameter("role");
		
		
		
		
		
		User user=new User();
		Cart cart=new Cart();
		user.setFirstName(firstname);
		user.setLastName(lastname);
		user.setEmail(email);
		user.setPassword(password);
		user.setAddress(address);
		user.setPhonenumber(phonenumber);
		user.setRole(role);
	
		UserDao userDao=new UserDaoImpl();
		if(userDao.save(user))
		{
		cart.setEmail(user.getEmail());
			cart.setGrandtotal(0.0f);
			
			CartDao cartdao=new CartDaoImpl();
			if(cartdao.save(cart))
			{
				RequestDispatcher rd=getServletContext().getRequestDispatcher("/Login.jsp");
				rd.forward(request, response);
			}
			
			
			
		}
		else
		{
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/signupform.jsp");
			rd.forward(request, response);
			
		}
}
}