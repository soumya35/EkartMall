package com.dao;
import com.database.ConnectionFactory;
import com.model.User;
import com.modelCategory.Category;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDaoImpl implements CategoryDao {

	Connection con;
	
	
	 @Override
	 public boolean save(Category c) {
		 
		 try {
			 con = ConnectionFactory.getDBConnection();
			 
			 
			 System.out.println("Inserting records into the table...");
	            PreparedStatement stmt = con.prepareStatement("insert into Category(CategoryName,CategoryDescription) values(?,?)");
	            stmt.setString(1, c.getCategoryName());
	            stmt.setString(2, c.getCategoryDescription());
	            
	            
	            int i = stmt.executeUpdate();
	            System.out.println(i + " records inserted");
	            
	            stmt.close();
	            con.close();
	            return true;
	            
	            
		 } catch (SQLException e) {
	            System.out.println(e);
	        }
	return false;
	    }


	@Override
	public boolean update(int cid) {
		
		return false;
	}


	@Override
	public boolean delete(int cid) {
		// TODO Auto-generated method stub
		return false;
	}
	 
	 
	            
		 
	 }

	

