package com.controllerCategory;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponse; 

import com.dao.CategoryDao;
import com.dao.UserDao;
import com.dao.UserDaoImpl;
import com.modelCategory.Category;
import com.dao.CategoryDaoImpl;

/**
 * Servlet implementation class AddCategoryServlet
 */
@WebServlet("/AddCategoryServlet")
public class AddCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCategoryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String categoryname=request.getParameter("Category Name");
		String categorydescription=request.getParameter("Category Description");
		System.out.println("Category Name : "+categoryname);
		System.out.println("Description : "+categorydescription);
		
		
		Category c=new Category();
		c.setCategoryName(categoryname);
		c.setCategoryDescription(categorydescription);
		
		
		CategoryDao cDao=new CategoryDaoImpl();
		if(cDao.save(c))
		{
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/category.jsp");
			 
			rd.forward(request, response);
			
		}
		else
		{
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/category.jsp");
			rd.forward(request, response);
			
		}
		
	}

}
