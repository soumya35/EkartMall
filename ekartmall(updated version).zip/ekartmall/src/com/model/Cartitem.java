package com.model;

public class Cartitem {
	
	int cartitemid;
	int cartid;
	String productName;
	double price;
	public Cartitem(int id, int cid, String name, Double price2) {
	
	}
	public int getCartitemid() {
		return cartitemid;
	}
	public int getCartid() {
		return cartid;
	}
	public void setCartid(int cartid) {
		this.cartid = cartid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setCartitemid(int cartitemid) {
		this.cartitemid = cartitemid;
	}
	
	
	
	

	
	
	
	

}
