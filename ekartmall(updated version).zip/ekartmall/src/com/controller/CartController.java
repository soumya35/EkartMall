package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.Cartitem;
import com.model.Product;
import com.model.Cart;
import com.dao.CartitemDao;
import com.dao.CartitemDaoImpl;
import com.dao.ProductDao;
import com.dao.ProductDaoImpl;
import com.dao.CartDaoImpl;
import com.dao.CartDao;


/**
 * Servlet implementation class CartController
 */
@WebServlet("/CartController")
public class CartController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String action = request.getParameter("action");
		 System.out.println("hello:"+action);
		
		 switch (action) {
		case "AddItemtoCart":
		       insertProduct(request, response);
		       
		       break;
		case "delete":
			System.out.println("inside delete form");
			
		   deleteProduct(request, response);
		   
		default:
		    cart(request, response);
		    break;
		}
	}
		 
		
	

	private void insertProduct(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("id"));
		ProductDao productdao=new ProductDaoImpl();
	    Product product=	productdao.getProduct(id);
		
		Cartitem c=new Cartitem();
		
		
		int cartid = Integer.parseInt(request.getParameter("cartid"));
		CartDao  cartdao =new CartDaoImpl();
		Cart cart= cartdao.getCart(cartid);
		
		HttpSession session = request.getSession(true);
	//	session.getAttribute("currentUser", user);
		
		
		CartitemDao cartitemdao=new CartitemDaoImpl();
	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) {
		
		
	}

	private void cart(HttpServletRequest request, HttpServletResponse response) {
		
		
	}

}
