package com.dao;
import com.database.ConnectionFactory;
import com.model.Category;
import com.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDaoImpl implements CategoryDao {

	Connection con;
	
	
	 @Override
	 public boolean save(Category c) {
		 
		 try {
			 con = ConnectionFactory.getDBConnection();
			 
			 
			 
	            PreparedStatement stmt = con.prepareStatement("insert into Category(CategoryName,CategoryDescription) values(?,?)");
	            stmt.setString(1, c.getCategoryName());
	            stmt.setString(2, c.getCategoryDescription());
	            
	            
	            int i = stmt.executeUpdate();
	            System.out.println(i + " records inserted");
	            
	            stmt.close();
	            con.close();
	            return true;
	            
	            
		 } catch (SQLException e) {
	            System.out.println(e);
	        }
	return false;
	    }


	

	




	@Override
	public boolean update(Category cid) {
		try {
			 con = ConnectionFactory.getDBConnection();
			
			
			 PreparedStatement stmt = con.prepareStatement("update Category set CategoryName=?,CategoryDescription=? where CategoryId=?");
		
			 stmt.setString(1,cid.getCategoryName());
			 stmt.setString(2, cid.getCategoryDescription());
			 stmt.setInt(3, cid.getCategoryid());
		
			
			 boolean rowUpdated = stmt.executeUpdate() > 0;
			
			 con.close();
			 return rowUpdated;
		} catch (SQLException e) {
            System.out.println(e);
        }
			 return false;
		
	}









	@Override
	public boolean delete(Category cid) {
		
		try {
			 con = ConnectionFactory.getDBConnection();
			 
			 System.out.println("Delete process starting...");
			 PreparedStatement stmt = con.prepareStatement("DELETE FROM Category where CategoryId = ?");
			 stmt.setInt(1,cid.getCategoryid());  
			 
			 boolean rowDeleted = stmt.executeUpdate() > 0;
			 con.close();
		return rowDeleted;
		} catch (SQLException e) {
            System.out.println(e);
        }
			 return false;
		
		
	}


	
	 






	@Override
	public boolean view(Category cid) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 
			 System.out.println("Viewing operation starting...");
			 PreparedStatement stmt = con.prepareStatement("select * from Category where CategoryId=?");
			 stmt.setInt(1,cid.getCategoryid()); 
			 ResultSet rs=stmt.executeQuery();
			 if(rs.next()){ 
			 
			 stmt.setInt(1,cid.getCategoryid());
			 stmt.setString(2, cid.getCategoryName());
			 stmt.setString(3, cid.getCategoryDescription());
			 }
			 con.close(); 
		} catch (SQLException e) {
            System.out.println(e);
        }
		return false;
	}
	
	
	
	@Override
	public List<Category> listAllCategories() {
		 List<Category> listCategory = new ArrayList<>();
		
		try {
		
         
	        String sql = "SELECT * FROM Category";
	         
	        con=ConnectionFactory.getDBConnection();
	         
	        Statement statement = con.createStatement();
	        ResultSet resultSet = statement.executeQuery(sql);
	         
	        while (resultSet.next()) {
	            int id = resultSet.getInt("categoryId");
	            String name = resultSet.getString("categoryName");
	            String description = resultSet.getString("categoryDescription");
	          
	            Category category = new Category(id, name,description);
	            listCategory.add(category);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
	        return listCategory;
	        
	}

	@Override
	public Category getCategory(int id)  {
		Category category = null;
		try {
	        String sql = "SELECT * FROM Category WHERE CategoryId = ?";
	         
	        con=ConnectionFactory.getDBConnection();
	         
	        PreparedStatement statement = con.prepareStatement(sql);
	        statement.setInt(1, id);
	         
	        ResultSet resultSet = statement.executeQuery();
	         
	        if (resultSet.next()) {
	            String categoryName = resultSet.getString("categoryName");
	            String categoryDescription = resultSet.getString("categoryDescription");
	         
	             
	            category = new Category(id, categoryName, categoryDescription);
	        }
	         
	        resultSet.close();
	        statement.close();
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
		
	        return category;
	}









	@Override
	public List<String> getCategoryName() {
		List<String> categoryName = new ArrayList<>();
			
			try {
			
	         
		        String sql = "SELECT CategoryName FROM Category";
		         
		        con=ConnectionFactory.getDBConnection();
		         
		        Statement statement = con.createStatement();
		        ResultSet resultSet = statement.executeQuery(sql);
		         
		        while (resultSet.next()) {
		           
		            String name = resultSet.getString("categoryName");
		            
		          
		           
		            categoryName.add(name);
		        }
		         
		        resultSet.close();
		        statement.close();
		         
		        
			}
			catch(Exception e)
			{
				System.out.println(e.toString());
			}
		        return categoryName;
		        
	}


}


