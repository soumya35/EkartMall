package com.database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
*
* @author Soumya & Titas
*/

public class ConnectionFactory {
	 
    //static String  connectionUrl ="jdbc:sqlserver://172.23.132.13;database=Ekart2;user=sa;password=password@123";
   
    
    static Connection con;
	static String connectionUrl = "jdbc:sqlserver://172.23.132.13:1433;databaseName=Ekart2;user=sa;password=password@123";
	
	public static Connection getDBConnection() {
	        Connection dbConnection = null;
	        try {
	        	
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	            System.out.println("load driver");
	        } catch (ClassNotFoundException e) {
	            System.out.println("hii:"+e.getMessage());
	        }
	        try {
	            dbConnection = DriverManager.getConnection(connectionUrl);
	            System.out.println("return con ob je");
	            return dbConnection;
	        } catch (SQLException e) {
	            
	        	System.out.println("hlo:"+e.getMessage());
	        }
	        return dbConnection;
	    }


}
