package com.dao;
import java.sql.SQLException;
import com.model.Cart;
import com.model.Cartitem;

public interface CartitemDao {

	public boolean save(Cartitem cartitem);
	public boolean delete(Cartitem cartitem);
	
	
}
