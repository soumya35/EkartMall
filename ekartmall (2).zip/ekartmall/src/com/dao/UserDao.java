package com.dao;
import com.model.User;

/**
*
* @author Soumya & Titas
*/
public interface UserDao {
    
    public boolean save(User user);
    

}