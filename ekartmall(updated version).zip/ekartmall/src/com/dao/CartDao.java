package com.dao;
import java.sql.SQLException;
import com.model.Cart;

/**
*
* @author Soumya & Titas
*/


public interface CartDao {

	public boolean save(Cart cart);
	public boolean update(Cart cart);
	public boolean delete(Cart cart);
	
	
}
