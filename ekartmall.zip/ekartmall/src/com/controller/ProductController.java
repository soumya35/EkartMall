package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CategoryDao;
import com.dao.CategoryDaoImpl;
import com.dao.ProductDao;
import com.dao.ProductDaoImpl;
import com.model.Category;
import com.model.Product;

/**
 * Servlet implementation class ProductController
 */
@WebServlet("/ViewProduct")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		 System.out.println("hello:"+action);
	        try {
	            switch (action) {
	            case "new":
	               showNewForm(request, response);
	                break;
	            case "insert":
	               insertProduct(request, response);
	                break;
	            case "delete":
	            	System.out.println("inside delete form");
	               deleteProduct(request, response);
	                break;
	            case "edit":
	            	System.out.println("inside edit form");
	              //  showEditForm(request, response);
	                break;
	            case "update":
	               updateProduct(request, response);
	                break;
	            default:
	                listproduct(request, response);
	                break;
	            }
	        }
	        catch (SQLException ex) {
	            throw new ServletException(ex);
	        }
	}

	
	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		Product c=new Product();
		c.setProductid(id);
		
		
		ProductDao productDao=new ProductDaoImpl();
        if(productDao.delete(c))
        {
        	
        	   response.sendRedirect("ViewProduct?action=");
        }
	
		
		
	}

	private void updateProduct(HttpServletRequest request, HttpServletResponse response) 
			 throws SQLException, IOException {
		
		int categoryid=Integer.parseInt(request.getParameter("category"));
		String productName = request.getParameter("ProductName");
        int quantity =Integer.parseInt(request.getParameter("Quantity"));
        float price = Float.parseFloat(request.getParameter("Price"));
        
        Product c=new Product();
        c.setCategoryid(categoryid);
        c.setProductname(productName);
        c.setQuantity(quantity);
          c.setPrice(price);
          
          ProductDao productDao=new ProductDaoImpl();
          if(productDao.update(c))
          {
          	
          	   response.sendRedirect("ViewProduct?action=");
          }
       
          
  	}
          
		
		

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		
       System.out.println("hi open product page");
       
       CategoryDao categorydao=new CategoryDaoImpl();
       List<Category> categorylist=categorydao.listAllCategories();
      
       
       request.setAttribute("listCategory",categorylist);
		  RequestDispatcher rd=getServletContext().getRequestDispatcher("/product.jsp");
		  rd.forward(request, response);
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
	
	
	private void insertProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     	int categoryid=Integer.parseInt(request.getParameter("category"));
		String productName = request.getParameter("ProductName");
        int quantity =Integer.parseInt(request.getParameter("Quantity"));
        float price = Float.parseFloat(request.getParameter("Price"));
		
		
        Product c=new Product();
        c.setCategoryid(categoryid);
        c.setProductname(productName);
        c.setQuantity(quantity);
          c.setPrice(price);
        
        ProductDao productDao=new ProductDaoImpl();
        if(productDao.save(c))
        {
        	
        	   response.sendRedirect("ViewProduct?action=");
        }
     
        
	}
	
	

	
	

	
	private void listproduct(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		ProductDao productDao=new ProductDaoImpl();
		List<Product> listproduct = productDao.listAllProducts();
		for(Product p:listproduct)
		{
			System.out.println("pid:"+p.getProductid());
			System.out.println("pname:"+p.getProductname());
		}
		request.setAttribute("listProduct", listproduct);
		RequestDispatcher dispatcher = request.getRequestDispatcher("ProductList.jsp");
		dispatcher.forward(request, response);
	}
	
	

}
