package com.dao;
import com.database.ConnectionFactory;
import com.model.User;
import com.model.Cart;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDaoImpl implements CartDao {
	Connection con;
	
	@Override
	public boolean save(Cart cart) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 System.out.println("Inserting records into the table...");
			 PreparedStatement stmt = con.prepareStatement("insert into Cart1( Email , GRANDTOTAL) values(?,?)");
			 
			 stmt.setString(1,cart.getEmail());
			 stmt.setFloat(2, cart.getGrandtotal());
			 
			 
			 int i = stmt.executeUpdate();
			 System.out.println(i + " records inserted");
	            
	            stmt.close();
	            con.close();
			 return true;
			 
		}
		catch (SQLException e) {
            System.out.println(e);
        }
		return false;
	}

	@Override
	public boolean update(Cart cart) {
		//try {
		//	con=ConnectionFactory.getDBConnection();
		//	PreparedStatement stmt = con.prepareStatement("update Cart set ");
			
		//}
		
		return false;
	}

	@Override
	public boolean delete(Cart cart) {
		
		return false;
	}

	
}
