package com.dao;
import com.database.ConnectionFactory;
import com.model.User;
import java.sql.Connection;
import javax.servlet.ServletContext;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
*
* @author Soumya & Titas
*/

public class UserDaoImpl implements UserDao {

    Connection con;

    @Override
    public boolean save(User user) {

        try {

           // System.out.println("hiiii");//
            con = ConnectionFactory.getConnection();

            System.out.println("Inserting records into the table...");
            PreparedStatement stmt = con.prepareStatement("insert into User2 values(?,?,?,?,?,?,?,?)");
            user.setRole("user");
            stmt.setString(1, user.getFirstName());
            stmt.setString(2, user.getLastName());
            stmt.setString(3, user.getPassword());
            stmt.setString(4, user.getAddress());
            stmt.setString(5, user.getRole());

            int i = stmt.executeUpdate();
            System.out.println(i + " records inserted");

            con.close();
            return true;

        } catch (SQLException e) {
            System.out.println(e);
        }
return false;
    }
    
    public List<User> getDetails() throws SQLException
    {
        con=ConnectionFactory.getConnection();
          Statement st=con.createStatement();
                  ResultSet      rs=st.executeQuery("Select * from user2");
			
                  User u=new User();
			List<User> listUser=new ArrayList<User>();
                        
                     while(rs.next())   
                     {
                         u.setFirstName(rs.getString("First Name"));
                        
                         listUser.add(u);
                     }
                     return listUser;
			
    }

}

