package com.dao;
import com.database.ConnectionFactory;
import com.model.Cart;
import com.model.Cartitem;
import com.dao.CartitemDao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class CartitemDaoImpl implements CartitemDao {
	Connection con;
	@Override
	public boolean save(Cartitem cartitem) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 System.out.println("Inserting records into the table...");
			 PreparedStatement stmt = con.prepareStatement("insert into CARTITEM( CARTID , PRODUCTNAME, PRICE) values(?,?,?)");
			 
			 stmt.setInt	(1,cartitem.getCartitemid());
			 stmt.setString	(2,cartitem.getProductName());
			 stmt.setDouble	(3,cartitem.getPrice());
			 
			 int i = stmt.executeUpdate();
			 System.out.println(i + " records inserted");
	            
			 stmt.close();
			 con.close();
			 return true;
			 
		}
			catch (SQLException e) {
            System.out.println(e);
        }
			return false;
	}

	@Override
	public boolean delete(Cartitem cartitem) {
		
			return false;
	}

	

}
