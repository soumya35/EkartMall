package com.model;

public class Product {
	
	int productid;
	int categoryid;
	String productName;
	int quantity;
	double price;
	
	
	public Product() {
    }
	
	
	public Product(int productid) {
        this.productid = productid;
    }
	
	
	
	
	public Product(int id, int cid, String name, int quantity2, Double price2) {
		// TODO Auto-generated constructor stub
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	public String getProductname() {
		return productName;
	}
	public void setProductname(String productname) {
		this.productName = productname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

}
