package com.controller;

import java.io.IOException;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDao;
import com.dao.UserDaoImpl;
import com.model.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType(getServletInfo());
		try {

			User user = new User();
			user.setEmail(request.getParameter("email"));
			user.setPassword(request.getParameter("password"));

			UserDao userDao = new UserDaoImpl();
			user = userDao.login(user);

		System.out.println("loin conr:"+user.isValid());
			if (user.isValid()) {
				HttpSession session = request.getSession(true);
				session.setAttribute("currentUser", user);
				
				if (user.getRole().equals("admin")) {
					RequestDispatcher rd = getServletContext().getRequestDispatcher("/AdminHome.jsp");
					rd.forward(request, response);
				}
				else
				{
					RequestDispatcher rd = getServletContext().getRequestDispatcher("/UserHome.jsp");
					rd.forward(request, response);
				}
				
				
			}

			else
				response.sendRedirect("/Login.jsp");
		}

		catch (Throwable theException) {
			System.out.println(theException);
		}
	}
}
