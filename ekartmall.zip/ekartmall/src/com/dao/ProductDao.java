package com.dao;
import java.sql.SQLException;
import java.util.List;

import com.model.Category;
import com.model.Product;

public interface ProductDao {
	
	public boolean save(Product p);
	public boolean update(Product p);
	public boolean delete(Product p);
	public boolean view(Product p);
	public List<Product> listAllProducts();
	public int getLastProductid();

}
