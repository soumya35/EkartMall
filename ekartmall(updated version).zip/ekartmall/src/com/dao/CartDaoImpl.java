package com.dao;
import com.database.ConnectionFactory;
import com.model.User;
import com.model.Cart;
import com.model.Product;

import java.sql.*;
import java.util.ArrayList;


public class CartDaoImpl implements CartDao {
	Connection con;
	
@Override
	
    public boolean save(Cart cart) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 System.out.println("Inserting records into the table...");
			 PreparedStatement stmt = con.prepareStatement("insert into cart1( Email , GRANDTOTAL) values(?,?)");
			 
			 stmt.setString(1,cart.getEmail());
			 stmt.setFloat(2, cart.getGrandtotal());
			 
			 
			 int i = stmt.executeUpdate();
			 System.out.println(i + " records inserted");
	            
	            stmt.close();
	            con.close();
			 return true;
			 
		}
		catch (SQLException e) {
            System.out.println(e);
        }
		return false;
	}

	@Override
	public boolean update(Cart cart) {
		//try {
		//	con=ConnectionFactory.getDBConnection();
		//	PreparedStatement stmt = con.prepareStatement("update Cart set ");
			
		//}
		
		return false;
	}

	@Override
	public boolean delete(Cart cart) {
		
		return false;
	}

	





  @Override

  public Cart getCart(String email) {
	  Cart c=new Cart();
	  try {
		  con = ConnectionFactory.getDBConnection();
		  PreparedStatement stmt = con.prepareStatement("select * from Cart1 where Email=?");
			 stmt.setString(1,email); 
			 ResultSet rs=stmt.executeQuery();
			 if(rs.next()){
				c.setCartid(rs.getInt("CARTID"));
				c.setEmail(rs.getString("Email"));
				c.setGrandtotal(rs.getFloat("GRANDTOTAL"));
			 }
			 
			 
	  }catch (SQLException e) {
	        System.out.println(e);
	    }

		return c;
	}

@Override
public boolean updateGrandTotal(int cartid, double price) {
	int update=0;
	
	try {
		 con = ConnectionFactory.getDBConnection();
		 PreparedStatement stmt = con.prepareStatement("update cart1 set GRANDTOTAL=? where cartid=?");
		 stmt.setDouble(1, price);
		 stmt.setInt(2,cartid);
		
		update=stmt.executeUpdate();
		
		 if(update>=1)
		 {
			 return true;
		 }
		 
	}catch (SQLException e) {
        System.out.println(e);
	}
	return false;
}

@Override
public double getCartTotal(int cartid) {
	double grandtotal = 0;
	try {
		 con = ConnectionFactory.getDBConnection();
		 PreparedStatement stmt = con.prepareStatement("select * from Cart1 where cartid=?");
		 stmt.setInt(1,cartid);
		 
		 ResultSet rs=stmt.executeQuery();
	     rs.next();
	     grandtotal=rs.getFloat("GRANDTOTAL");
		 
		 
	}catch (SQLException e) {
       System.out.println(e);
	}
	return grandtotal;
}
	}
			 
	  
	  

