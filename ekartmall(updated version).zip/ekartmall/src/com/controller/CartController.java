package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.Cartitem;
import com.model.Product;
import com.model.User;
import com.model.Cart;
import com.dao.CartitemDao;
import com.dao.CartitemDaoImpl;
import com.dao.ProductDao;
import com.dao.ProductDaoImpl;
import com.dao.CartDaoImpl;
import com.dao.CartDao;


/**
 * Servlet implementation class CartController
 */
@WebServlet("/CartController")
public class CartController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String action = request.getParameter("action");
		 System.out.println("hello:"+action);
		
		 switch (action) {
		case "AddItemtoCart":
		       insertProduct(request, response);
		       
		       break;
		case "delete":
			System.out.println("inside delete form");
			
		   deleteProduct(request, response);
		   
		default:
		    showItem(request, response);
		    break;
		}
	}
		 
		
	

	private void insertProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		
	
		System.out.println("pass pid"+id);
		ProductDao productdao=new ProductDaoImpl();
	    Product product=	productdao.getProduct(id);
		
	
		
		System.out.println("produ="+product.getPrice()+"name="+product.getProductname());
		
		
		
		HttpSession session = request.getSession(true);
		User user = (User)session.getAttribute("currentUser");
		
		System.out.println("email"+user.getEmail());
		CartDao  cartdao =new CartDaoImpl();
		Cart cart= cartdao.getCart(user.getEmail());
		
		System.out.println("id"+cart.getCartid());
		
		
		
		double grandtotal=cartdao.getCartTotal(cart.getCartid());
		System.out.println("grandtoal"+grandtotal);
		double NewTotal=grandtotal+product.getPrice();
		System.out.println("new total"+NewTotal);
		
		
		Cartitem cartitem=new Cartitem();
		cartitem.setCartid(cart.getCartid());
		cartitem.setProductName(product.getProductname());
		cartitem.setPrice(product.getPrice());
	
		CartitemDao cartitemdao=new CartitemDaoImpl();
		cartitemdao.AddItemtoCart(cartitem);
		
		if(cartdao.updateGrandTotal(cart.getCartid(),NewTotal))
		{
			
		
		ProductDao productDao=new ProductDaoImpl();
		List<Product> listproduct = productDao.listAllProducts();
		
		request.setAttribute("listProduct", listproduct);
		RequestDispatcher dispatcher = request.getRequestDispatcher("AllProduct.jsp");
		dispatcher.forward(request, response);
		}
		
	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) {
		
		
	}

	private void cart(HttpServletRequest request, HttpServletResponse response) {
		
		
	}

}
