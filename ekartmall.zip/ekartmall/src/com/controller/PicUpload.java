package com.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.List;
import com.dao.ProductDaoImpl;
import com.model.Product;
import com.dao.ProductDao;


import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;



/**
 * Servlet implementation class Guru_upload
 */
@WebServlet("/PicUpload")
public class PicUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PicUpload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    
    
   
	private String getLastProductid()
            throws SQLException, IOException {
		
		
		
		ProductDao productDao=new ProductDaoImpl();
		
		String pid=String.valueOf(productDao.getLastProductid());
			
		return pid;	
		
		}
    
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 PrintWriter out = response.getWriter();
		   
		  if(!ServletFileUpload.isMultipartContent(request)){
		   out.println("Nothing to upload");
		   return; 
		  }
		  FileItemFactory itemfactory = new DiskFileItemFactory(); 
		  ServletFileUpload upload = new ServletFileUpload(itemfactory);
		  try{
		   List<FileItem>  items = upload.parseRequest(request);
		   for(FileItem item:items){
		     
		    String contentType = item.getContentType();
		    if(!contentType.equals("image/jpeg"))
		    {
		     out.println("only jpg format image files supported");
		     continue;
		    }
		    File uploadDir = new File("D:\\eclipse-workspace\\ekartmall\\WebContent\\images");
		    String filename="prodid"+getLastProductid();
		    System.out.println(filename);
		   
		    File imgFile = new File(uploadDir + File.separator + filename+".jpeg");
		    
		    if(imgFile.createNewFile())
		    {    
		    System.out.println("image upload");
		    	item.write(imgFile);
		    }
		    out.println("File Saved Successfully");
		   }
		  }
		  catch(FileUploadException  e){
		    
		   out.println("upload fail");
		  }
		  catch(Exception ex){
		    
		   out.println("can't save");
		  }
	}
}
		 
		
	