package com.dao;
import com.database.ConnectionFactory;
import com.model.Cart;
import com.model.Cartitem;
import com.model.Product;
import com.dao.CartitemDao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class CartitemDaoImpl implements CartitemDao {
	Connection con;
	@Override
	public boolean AddItemtoCart(Cartitem cartitem) {
		try {
			 con = ConnectionFactory.getDBConnection();
			 System.out.println("Inserting records into the table...");
			 PreparedStatement stmt = con.prepareStatement("insert into CARTITEM( CARTID , PRODUCTNAME, PRICE) values(?,?,?)");
			 
			 stmt.setInt	(1,cartitem.getCartid());
			 stmt.setString	(2,cartitem.getProductName());
			 stmt.setDouble	(3,cartitem.getPrice());
			 
			 int i = stmt.executeUpdate();
			 System.out.println(i + " records inserted");
	            
			 stmt.close();
			 con.close();
			 return true;
			 
		}
			catch (SQLException e) {
            System.out.println(e);
        }
			return false;
	}

	@Override
	public boolean delete(Cartitem cartitem) {
		
			return false;
	}

	@Override
	public int itemCount(int cartid) {
		 int c=0;
		  try {
			  con = ConnectionFactory.getDBConnection();
			  PreparedStatement stmt = con.prepareStatement("select * from cartitem");
				 
				 ResultSet rs=stmt.executeQuery();
				while( rs.next())
					{
					c++;
					}
				 System.out.println("Count"+c);
				 
				 
		  }catch (SQLException e) {
		        System.out.println(e);
		    }

			return c;
	}

	@Override
	public List<Cartitem> listAllCartItem() {
		 List<Cartitem> listallcartitem = new ArrayList<>();
		 try {
			 String sql = "SELECT * FROM cartitem";
	         
		        con=ConnectionFactory.getDBConnection();   
		        Statement statement = con.createStatement();
		        ResultSet resultSet = statement.executeQuery(sql);
		        while (resultSet.next()) {
		        	int id = resultSet.getInt("cartitemid");
		        	 int cid = resultSet.getInt("cartid");
		        	 String name = resultSet.getString("productname");
		        	 Double price = resultSet.getDouble("price");
		        	 
		        	 
		        	 Cartitem cartitem = new Cartitem(id,cid,name,price);
		        	 listallcartitem.add(cartitem);
		        	 
		        	 for(Cartitem p:listallcartitem)
		        	 {
		        		 System.out.println("pid:"+p.getCartitemid());
				        	System.out.println("name:"+p.getProductName());
		        	 }
		        	 resultSet.close();
				        statement.close();
				         
		        }
		 }
		        catch(Exception e)
				{
					System.out.println(e.toString());
				}
			        
		       
		       
		        
		        
		        
		return listallcartitem;
	}

	

	

}
