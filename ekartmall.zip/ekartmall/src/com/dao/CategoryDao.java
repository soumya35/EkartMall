package com.dao;
import java.sql.SQLException;

import com.modelCategory.Category;


public interface CategoryDao {

	public boolean save(Category c);
	
	public boolean update(int cid);
	public boolean delete(int cid);
	}
	

