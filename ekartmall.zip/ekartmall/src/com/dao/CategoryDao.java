package com.dao;
import java.sql.SQLException;
import java.util.List;

import com.model.Category;


public interface CategoryDao {

	public boolean save(Category c);
	public boolean update(Category cid) ;
	public boolean delete(Category cid);
	public boolean view(Category cid);
	public List<Category> listAllCategories();
	 public Category getCategory(int id) ;
	 public List<String> getCategoryName();
	}
	

